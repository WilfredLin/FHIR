# Exercise 4 - Medical Certificate

[E4P4Q1] Which of the following is the best way to upload multiple Image files (PDF) using FHIR message(s)?

  (A) Create multiple items in `DocumentReference.content`.

  (B) Create multiple DocumentReference along with the items in `Composition.section.entry`.

  (C) Uploading multiple Image files (PDF) is not supported.

  (D) Upload two FHIR message with the same record key but with different Image file (PDF).

Answer: &lt;PUT YOUR ANSWER HERE&gt;

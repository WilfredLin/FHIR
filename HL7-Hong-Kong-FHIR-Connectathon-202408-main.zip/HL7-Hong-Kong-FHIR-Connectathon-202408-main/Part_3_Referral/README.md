# Exercise 3 - Referral

[E4P3Q1] Who is the Referring Doctor found in the PDF inside the REF_Level_1_Sample.json file.

  (A) LAU, DAISY

  (B) DR. HAPPY CHEUNG

  (C) CHAN, HO DAVID

  (D) CHAN, SIU LING

Answer: &lt;PUT YOUR ANSWER HERE&gt;

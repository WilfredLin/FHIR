# Exercise 1 - Laboratory Result (Anatomical Pathology Result) Records

## [E5P1Q1] How many Diagnosis Findings are present in the LABAP_Level_3_Sample?

(A) 0

(B) 1

(C) 2

(D) 3

Answer: &lt;PUT YOUR ANSWER HERE&gt;

## [E5P1Q2] Where can we find the Referral document reference number in the LABAP_Level_1_Sample?

(A) Composition.identifier.value

(B) DiagnosticReport.identifier.value

(C) ServiceRequest.identifier.value

(D) Organization.identifier.value

Answer: &lt;PUT YOUR ANSWER HERE&gt;
